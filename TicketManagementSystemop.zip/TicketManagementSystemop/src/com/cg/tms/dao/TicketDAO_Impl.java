package com.cg.tms.dao;



import java.util.ArrayList;

import java.util.Collection;

import java.util.Collections;

import java.util.HashMap;

import java.util.List;

import java.util.Map;

import java.util.Map.Entry;

import java.util.Set;



import com.cg.tms.dto.TicketBean;

import com.cg.tms.dto.TicketCategory;

import com.cg.tms.util.UtilDB;



public class TicketDAO_Impl implements TicketDAO{



 Map<String, TicketBean> ticketLog = new HashMap<>();

 @Override

 public boolean raiseNewTicket(TicketBean ticketBean) {

 // TODO Auto-generated method stub

 ticketLog.put(ticketBean.getTicketno(), ticketBean);



 TicketBean ac1 = ticketLog.get(ticketBean.getTicketno());

 if(ac1!=null)

  return true;

 else

  return false;

 }



 @Override

 public List<TicketCategory> listTicketCategory() {

 // TODO Auto-generated method stub

    int i=1;

 //Getting Collection of values from HashMap



 List<TicketCategory> tlist = new ArrayList<>();

 for(Entry<String,String> entry: UtilDB.getTicketCategoryEntries().entrySet()) {

  String s = ""+i;

  String s1 = entry.getValue();

  TicketCategory tc = new TicketCategory(s,s1);

  s="";

  i++;

  tlist.add(tc);

 }

 return tlist;

 }



}

